package com.modularapproach.ModularApproch_with_CRUD_Oprations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModularApprochWithCrudOprationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModularApprochWithCrudOprationsApplication.class, args);
	}

}
