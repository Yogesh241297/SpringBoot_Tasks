package com.modularapproach.ModularApproch_with_CRUD_Oprations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModularApprochWithCrudOprationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
