package com.example.SpringBoot_Controller_HomeworkTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootControllerHomeworkTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootControllerHomeworkTaskApplication.class, args);
	}

}
