package com.pvl.SpringBoot_with_Controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
